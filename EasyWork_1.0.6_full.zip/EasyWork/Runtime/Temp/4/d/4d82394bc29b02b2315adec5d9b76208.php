<?php
//000000000000s:60:"SELECT COUNT(*) AS tp_count FROM `dwin_user_table` LIMIT 1  ";
?>