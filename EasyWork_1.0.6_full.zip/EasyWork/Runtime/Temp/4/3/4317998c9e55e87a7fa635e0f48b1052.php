<?php
//000000000000s:66:"SELECT COUNT(*) AS tp_count FROM `dwin_user_group_table` LIMIT 1  ";
?>