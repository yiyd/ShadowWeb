<?php
//000000000000s:80:"SELECT worklog_id as id FROM `dwin_worklog_main_table` WHERE ( `task_id` = 15 ) ";
?>