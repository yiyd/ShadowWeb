<?php
//000000000000s:68:"SELECT * FROM `dwin_user_group_table` WHERE ( `id` = '6' ) LIMIT 1  ";
?>