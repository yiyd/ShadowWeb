<?php
//000000000000s:112:"SELECT * FROM `dwin_user_table` WHERE ( `username` = 'admin' ) AND ( `id` = '1' ) AND ( `status` = 1 ) LIMIT 1  ";
?>