<?php
//000000000000s:66:"SELECT * FROM `dwin_user_table` WHERE ( 1=1 AND id='1' ) LIMIT 1  ";
?>