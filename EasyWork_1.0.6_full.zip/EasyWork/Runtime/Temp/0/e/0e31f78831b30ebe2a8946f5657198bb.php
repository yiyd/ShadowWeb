<?php
//000000000000s:157:"SELECT * FROM `dwin_log_table` WHERE ( id in(( SELECT log_id as id FROM `dwin_log_main_table` WHERE ( `task_id` = 5 )  )) ) ORDER BY addtime desc LIMIT 0,5  ";
?>