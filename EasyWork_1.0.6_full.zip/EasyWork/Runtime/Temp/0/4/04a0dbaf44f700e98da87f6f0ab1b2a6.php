<?php
//000000000000s:77:"SELECT * FROM `dwin_user_company_table` WHERE ( `type` = 0 ) ORDER BY id asc ";
?>