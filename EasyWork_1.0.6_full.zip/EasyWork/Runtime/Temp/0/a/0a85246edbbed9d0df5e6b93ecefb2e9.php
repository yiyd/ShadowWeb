<?php
//000000000000s:55:"SELECT `url` FROM `dwin_menu` WHERE ( id=16 ) LIMIT 1  ";
?>