<?php
//000000000000s:156:"SELECT COUNT(*) AS tp_count FROM `dwin_log_table` WHERE ( `id` in (( SELECT log_id as id FROM `dwin_log_main_table` WHERE ( `task_id` = 13 )  )) ) LIMIT 1  ";
?>