<?php
//000000000000s:84:"SELECT SUM(tt1.worktime) FROM dwin_worklog_table as tt1 WHERE ( tt1.task_id=t1.id ) ";
?>