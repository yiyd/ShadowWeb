<?php
//000000000000s:183:"SELECT * FROM `dwin_worklog_table` WHERE ( id in (( SELECT worklog_id as id FROM `dwin_worklog_main_table` WHERE ( `task_id` = 13 )  )) and YEAR(addtime)=2015 and MONTH(addtime)=07 ) ";
?>