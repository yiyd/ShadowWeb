<?php
//000000000000s:111:"SELECT * FROM `dwin_user_table` WHERE ( `username` = 'demo' ) AND ( `id` = '2' ) AND ( `status` = 1 ) LIMIT 1  ";
?>