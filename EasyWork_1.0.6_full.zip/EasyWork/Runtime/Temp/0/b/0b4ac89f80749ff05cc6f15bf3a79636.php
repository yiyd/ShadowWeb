<?php
//000000000000s:77:"SELECT * FROM `dwin_task_main_table` WHERE ( 1=1 AND task_id='15' ) LIMIT 1  ";
?>