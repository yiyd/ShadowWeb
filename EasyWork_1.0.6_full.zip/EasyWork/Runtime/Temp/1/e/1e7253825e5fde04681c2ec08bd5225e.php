<?php
//000000000000s:135:"SELECT COUNT(*) AS tp_count FROM `dwin_task_table` WHERE ( TO_DAYS(NOW())>TO_DAYS(`enddate`) and `status`<>51 and `to_id`=2 ) LIMIT 1  ";
?>