<?php
//000000000000s:64:"SELECT * FROM `dwin_notice_table` WHERE ( `id` = '2' ) LIMIT 1  ";
?>