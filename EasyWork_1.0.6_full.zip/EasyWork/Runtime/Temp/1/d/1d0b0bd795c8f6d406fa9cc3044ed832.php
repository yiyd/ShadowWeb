<?php
//000000000000s:60:"SELECT `id` FROM `dwin_menu` WHERE ( _parentId=5 ) LIMIT 1  ";
?>