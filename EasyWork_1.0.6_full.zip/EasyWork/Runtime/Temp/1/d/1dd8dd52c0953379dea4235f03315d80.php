<?php
//000000000000s:81:"SELECT * FROM `dwin_menu` WHERE ( status=1 and id in(2,3,5,6,7,8,4,9,10,11,12) ) ";
?>