<?php
//000000000000s:75:"SELECT `id`,title as text FROM `dwin_project_table` WHERE ( `status`<>65 ) ";
?>