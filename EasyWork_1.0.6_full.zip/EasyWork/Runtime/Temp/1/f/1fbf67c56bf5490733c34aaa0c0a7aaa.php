<?php
//000000000000s:68:"SELECT `username` FROM `dwin_user_table` WHERE ( id in() ) LIMIT 1  ";
?>