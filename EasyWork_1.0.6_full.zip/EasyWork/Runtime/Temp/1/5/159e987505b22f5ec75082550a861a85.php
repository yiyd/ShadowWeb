<?php
//000000000000s:99:"SELECT COUNT(*) AS tp_count FROM `dwin_task_table` WHERE ( `pro_id`=10 and `status`<>51 ) LIMIT 1  ";
?>