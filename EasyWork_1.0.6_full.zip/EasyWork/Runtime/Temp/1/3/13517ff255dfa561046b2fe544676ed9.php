<?php
//000000000000s:67:"SELECT COUNT(*) AS tp_count FROM `dwin_sms_receive_table` LIMIT 1  ";
?>