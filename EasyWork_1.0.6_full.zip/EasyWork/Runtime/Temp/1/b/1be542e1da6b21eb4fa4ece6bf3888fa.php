<?php
//000000000000s:71:"SELECT `access` FROM `dwin_user_group_table` WHERE ( id="1" ) LIMIT 1  ";
?>