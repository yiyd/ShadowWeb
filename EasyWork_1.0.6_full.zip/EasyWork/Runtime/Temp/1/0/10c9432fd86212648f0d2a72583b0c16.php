<?php
//000000000000s:39:"SELECT * FROM `dwin_sms_receive_table` ";
?>