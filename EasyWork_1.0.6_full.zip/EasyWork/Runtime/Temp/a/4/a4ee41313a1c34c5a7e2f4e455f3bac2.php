<?php
//000000000000s:61:"SELECT COUNT(*) AS tp_count FROM `dwin_files_table` LIMIT 1  ";
?>