<?php
//000000000000s:51:"SELECT * FROM `dwin_menu` WHERE ( id=32 ) LIMIT 1  ";
?>