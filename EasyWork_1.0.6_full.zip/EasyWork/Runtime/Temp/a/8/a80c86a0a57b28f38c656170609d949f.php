<?php
//000000000000s:137:"SELECT COUNT(*) AS tp_count FROM `dwin_task_table` WHERE ( `pro_id`=10 and TO_DAYS(NOW())>TO_DAYS(`enddate`) and `status`<>51 ) LIMIT 1  ";
?>