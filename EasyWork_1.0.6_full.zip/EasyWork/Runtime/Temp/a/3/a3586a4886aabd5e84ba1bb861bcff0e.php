<?php
//000000000000s:81:"SELECT MIN(files_id) FROM `dwin_files_main_table` WHERE ( `pro_id`=10 ) LIMIT 1  ";
?>