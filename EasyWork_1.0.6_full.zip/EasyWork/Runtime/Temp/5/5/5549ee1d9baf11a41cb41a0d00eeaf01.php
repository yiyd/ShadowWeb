<?php
//000000000000s:127:"SELECT * FROM `dwin_user_table` WHERE ( `username` = 'demo' ) AND ( `password` = '202cb962ac59075b964b07152d234b70' ) LIMIT 1  ";
?>