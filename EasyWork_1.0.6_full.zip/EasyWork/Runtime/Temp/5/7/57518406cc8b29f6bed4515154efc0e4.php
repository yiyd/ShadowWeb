<?php
//000000000000s:100:"SELECT `reply_id` FROM `dwin_reply_main_table` WHERE ( `pro_id`=10 and task_id=0 and worklog_id=0 ) ";
?>