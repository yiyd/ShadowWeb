<?php
//000000000000s:66:"SELECT * FROM `dwin_user_table` WHERE ( 1=1 AND id='2' ) LIMIT 1  ";
?>