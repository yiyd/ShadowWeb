<?php
//000000000000s:108:"SELECT `group_id`,`company_id`,`part_id` FROM `dwin_user_main_table` WHERE ( 1=1 AND user_id='3' ) LIMIT 1  ";
?>