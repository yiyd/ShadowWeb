<?php
//000000000000s:65:"SELECT `mode` FROM `dwin_menu` WHERE ( code='Project' ) LIMIT 1  ";
?>