<?php
//000000000000s:66:"SELECT COUNT(*) AS tp_count FROM `dwin_reply_main_table` LIMIT 1  ";
?>