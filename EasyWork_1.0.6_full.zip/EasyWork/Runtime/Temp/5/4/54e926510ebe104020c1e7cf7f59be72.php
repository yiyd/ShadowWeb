<?php
//000000000000s:66:"SELECT COUNT(*) AS tp_count FROM `dwin_files_main_table` LIMIT 1  ";
?>