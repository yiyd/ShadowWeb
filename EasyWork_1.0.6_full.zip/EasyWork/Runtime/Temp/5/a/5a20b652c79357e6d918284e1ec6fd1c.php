<?php
//000000000000s:93:"SELECT ROUND(SUM(tt1.worktime),1) FROM dwin_worklog_table as tt1 WHERE ( tt1.task_id=t1.id ) ";
?>