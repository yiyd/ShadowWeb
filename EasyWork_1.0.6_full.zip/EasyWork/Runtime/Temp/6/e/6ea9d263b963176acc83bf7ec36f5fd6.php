<?php
//000000000000s:169:"SELECT * FROM `dwin_reply_table` WHERE ( `id` in (( SELECT `reply_id` FROM `dwin_reply_main_table` WHERE ( `pro_id`=3 and task_id=0 and worklog_id=0 )  )) ) LIMIT 0,10  ";
?>