<?php
//000000000000s:61:"SELECT `mode` FROM `dwin_menu` WHERE ( code='Log' ) LIMIT 1  ";
?>