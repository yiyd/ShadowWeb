<?php
//000000000000s:64:"SELECT * FROM `dwin_worklog_table` WHERE ( `id` = 30 ) LIMIT 1  ";
?>