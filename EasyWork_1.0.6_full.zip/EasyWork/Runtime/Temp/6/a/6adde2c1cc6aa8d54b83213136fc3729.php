<?php
//000000000000s:127:"SELECT GROUP_CONCAT(id) as id FROM `dwin_project_table` WHERE ( `ststus`=65 and TO_DAYS(NOW()) - TO_DAYS(`uptime`)> ) LIMIT 1  ";
?>