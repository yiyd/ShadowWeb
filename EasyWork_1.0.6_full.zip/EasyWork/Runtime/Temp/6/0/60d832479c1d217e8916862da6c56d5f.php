<?php
//000000000000s:54:"SELECT COUNT(*) AS tp_count FROM `dwin_menu` LIMIT 1  ";
?>