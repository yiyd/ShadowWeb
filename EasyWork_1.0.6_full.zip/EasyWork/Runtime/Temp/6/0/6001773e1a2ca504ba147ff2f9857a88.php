<?php
//000000000000s:62:"SELECT COUNT(*) AS tp_count FROM `dwin_mssage_table` LIMIT 1  ";
?>