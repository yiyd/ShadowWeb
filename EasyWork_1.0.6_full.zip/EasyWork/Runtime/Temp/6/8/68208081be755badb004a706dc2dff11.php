<?php
//000000000000s:112:"SELECT id as id,username as text FROM `dwin_user_table` WHERE ( status=1 ) ORDER BY convert(text using gbk) asc ";
?>