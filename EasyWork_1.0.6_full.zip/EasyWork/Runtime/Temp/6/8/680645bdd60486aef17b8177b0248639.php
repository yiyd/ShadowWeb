<?php
//000000000000s:101:"SELECT COUNT(*) AS tp_count FROM `dwin_sms_receive_table` WHERE ( user_id= and `status`=0 ) LIMIT 1  ";
?>