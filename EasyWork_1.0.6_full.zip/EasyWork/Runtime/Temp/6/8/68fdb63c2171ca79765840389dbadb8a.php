<?php
//000000000000s:65:"SELECT `mode` FROM `dwin_menu` WHERE ( code='Setting' ) LIMIT 1  ";
?>