<?php
//000000000000s:56:"SELECT COUNT(*) AS tp_count FROM `dwin_config` LIMIT 1  ";
?>