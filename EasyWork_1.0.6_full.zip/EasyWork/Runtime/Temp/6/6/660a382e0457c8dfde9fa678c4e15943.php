<?php
//000000000000s:83:"SELECT * FROM `dwin_worklog_main_table` WHERE ( 1=1 AND worklog_id='30' ) LIMIT 1  ";
?>