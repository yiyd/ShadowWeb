<?php
//000000000000s:62:"SELECT `mode` FROM `dwin_menu` WHERE ( code='Comy' ) LIMIT 1  ";
?>