<?php
//000000000000s:143:"SELECT * FROM `dwin_reply_table` WHERE ( `id` in (( SELECT `reply_id` FROM `dwin_reply_main_table` WHERE ( `worklog_id`=30 )  )) ) LIMIT 0,10  ";
?>