<?php
//000000000000s:76:"SELECT MIN(startdate) FROM `dwin_task_table` WHERE ( `pro_id`=10 ) LIMIT 1  ";
?>