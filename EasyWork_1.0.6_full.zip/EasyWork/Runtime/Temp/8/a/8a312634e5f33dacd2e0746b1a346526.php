<?php
//000000000000s:121:"SELECT COUNT(*) AS tp_count FROM `dwin_task_table` WHERE ( TO_DAYS(NOW())>TO_DAYS(`enddate`) and `status`<>51 ) LIMIT 1  ";
?>