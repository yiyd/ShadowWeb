<?php
//000000000000s:227:"SELECT t1.id as id,t1._parentId as _parentId,concat_ws('',' <span class=\"up-font-over\">[',t2.val,']<\/span> ',t1.title) as text FROM dwin_task_table as t1 LEFT JOIN  dwin_linkage as t2 on t2.id=t1.type WHERE ( t1.pro_id=10 ) ";
?>