<?php
//000000000000s:63:"SELECT * FROM `dwin_linkage` WHERE ( 1=1 AND id='0' ) LIMIT 1  ";
?>