<?php
//000000000000s:94:"SELECT pro_id as id FROM `dwin_task_table` WHERE ( `to_id`=2 or `from_id`=2 ) ORDER BY pro_id ";
?>