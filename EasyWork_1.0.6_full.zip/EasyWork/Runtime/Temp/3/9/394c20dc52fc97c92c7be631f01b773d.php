<?php
//000000000000s:86:"SELECT `reply_id` FROM `dwin_reply_main_table` WHERE ( `task_id`=5 and worklog_id=0 ) ";
?>