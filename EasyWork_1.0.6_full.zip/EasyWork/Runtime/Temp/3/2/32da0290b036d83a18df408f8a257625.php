<?php
//000000000000s:98:"SELECT COUNT(*) AS tp_count FROM `dwin_task_table` WHERE ( `pro_id`=3 and `status`<>51 ) LIMIT 1  ";
?>