<?php
//000000000000s:74:"SELECT MAX(enddate) FROM `dwin_task_table` WHERE ( `pro_id`=10 ) LIMIT 1  ";
?>