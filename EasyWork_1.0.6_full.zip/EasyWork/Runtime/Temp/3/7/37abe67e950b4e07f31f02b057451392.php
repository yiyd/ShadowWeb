<?php
//000000000000s:86:"SELECT * FROM `dwin_notice_table` WHERE ( status>0 ) ORDER BY status asc,addtime desc ";
?>