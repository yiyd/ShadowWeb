<?php
//000000000000s:171:"SELECT MIN(tt6.addtime) FROM dwin_worklog_table as tt6 WHERE ( tt6.task_id IN(( SELECT tt1.task_id as id FROM dwin_task_main_table as tt1 WHERE ( tt1.pro_id=t1.id )  )) ) ";
?>