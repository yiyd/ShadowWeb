<?php
//000000000000s:59:"SELECT COUNT(*) AS tp_count FROM `dwin_log_table` LIMIT 1  ";
?>