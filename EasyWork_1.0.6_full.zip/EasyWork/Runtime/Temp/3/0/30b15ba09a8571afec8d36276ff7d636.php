<?php
//000000000000s:56:"SELECT `code` FROM `dwin_menu` WHERE ( id=19 ) LIMIT 1  ";
?>