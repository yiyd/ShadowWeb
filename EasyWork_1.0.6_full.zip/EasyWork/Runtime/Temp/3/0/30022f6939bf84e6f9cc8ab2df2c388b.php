<?php
//000000000000s:64:"SELECT COUNT(*) AS tp_count FROM `dwin_log_main_table` LIMIT 1  ";
?>