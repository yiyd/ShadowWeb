<?php
//000000000000s:56:"SELECT * FROM `dwin_user_table` WHERE ( id=3 ) LIMIT 1  ";
?>