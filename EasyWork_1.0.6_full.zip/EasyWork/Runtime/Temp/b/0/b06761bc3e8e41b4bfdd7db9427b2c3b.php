<?php
//000000000000s:64:"SELECT * FROM `dwin_linkage` WHERE ( 1=1 AND id='51' ) LIMIT 1  ";
?>