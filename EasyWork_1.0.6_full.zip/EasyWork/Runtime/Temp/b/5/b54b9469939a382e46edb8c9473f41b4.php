<?php
//000000000000s:315:"SELECT concat_ws('','<div class=\"wt\" onclick=\"getDetailWork(',tt1.id,')\"><span class=\"wl\">',tt2.val,'</span><span class=\"wr\">',ROUND(tt1.worktime,1),'<span></div>') FROM dwin_worklog_table as tt1 LEFT JOIN  dwin_linkage as tt2 on tt2.id = tt1.status WHERE ( tt1.task_id=t1.id and tt1.addtime='2015-07-23' ) ";
?>