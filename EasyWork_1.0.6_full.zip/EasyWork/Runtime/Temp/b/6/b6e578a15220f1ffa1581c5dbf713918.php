<?php
//000000000000s:173:"SELECT COUNT(*) AS tp_count FROM `dwin_reply_table` WHERE ( `id` in (( SELECT `reply_id` FROM `dwin_reply_main_table` WHERE ( `task_id`=15 and worklog_id=0 )  )) ) LIMIT 1  ";
?>