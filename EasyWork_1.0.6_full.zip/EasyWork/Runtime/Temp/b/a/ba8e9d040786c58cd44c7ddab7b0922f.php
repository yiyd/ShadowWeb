<?php
//000000000000s:52:"SELECT `id` FROM `dwin_menu` WHERE ( _parentId=13 ) ";
?>