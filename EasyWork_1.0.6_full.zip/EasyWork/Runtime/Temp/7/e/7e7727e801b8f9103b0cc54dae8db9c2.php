<?php
//000000000000s:79:"SELECT worklog_id as id FROM `dwin_worklog_main_table` WHERE ( `task_id` = 5 ) ";
?>