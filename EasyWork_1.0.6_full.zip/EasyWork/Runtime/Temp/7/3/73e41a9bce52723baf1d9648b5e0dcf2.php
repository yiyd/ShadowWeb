<?php
//000000000000s:57:"SELECT COUNT(*) AS tp_count FROM `dwin_linkage` LIMIT 1  ";
?>