<?php
//000000000000s:63:"SELECT `mode` FROM `dwin_menu` WHERE ( code='Files' ) LIMIT 1  ";
?>