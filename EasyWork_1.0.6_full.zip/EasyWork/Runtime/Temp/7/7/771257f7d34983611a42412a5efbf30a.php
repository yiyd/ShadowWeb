<?php
//000000000000s:40:"SELECT * FROM `dwin_user_company_table` ";
?>