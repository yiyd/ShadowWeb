<?php
//000000000000s:29:"SELECT * FROM `dwin_linkage` ";
?>