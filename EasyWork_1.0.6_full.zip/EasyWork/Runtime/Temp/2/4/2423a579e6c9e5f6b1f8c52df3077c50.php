<?php
//000000000000s:63:"SELECT COUNT(*) AS tp_count FROM `dwin_worklog_table` LIMIT 1  ";
?>