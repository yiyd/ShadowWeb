<?php
//000000000000s:61:"SELECT `id` FROM `dwin_menu` WHERE ( _parentId=12 ) LIMIT 1  ";
?>