<?php
//000000000000s:65:"SELECT COUNT(*) AS tp_count FROM `dwin_log_dmain_table` LIMIT 1  ";
?>