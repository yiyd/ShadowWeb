<?php
//000000000000s:55:"SELECT * FROM `dwin_user_table` WHERE ( id= ) LIMIT 1  ";
?>