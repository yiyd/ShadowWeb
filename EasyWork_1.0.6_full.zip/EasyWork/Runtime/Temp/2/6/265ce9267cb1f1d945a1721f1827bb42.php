<?php
//000000000000s:65:"SELECT `view` FROM `dwin_menu` WHERE ( code='Worklog' ) LIMIT 1  ";
?>