<?php
//000000000000s:70:"SELECT COUNT(*) AS tp_count FROM `dwin_files_baseinfo_table` LIMIT 1  ";
?>