<?php
//000000000000s:158:"SELECT * FROM `dwin_log_table` WHERE ( id in(( SELECT log_id as id FROM `dwin_log_main_table` WHERE ( `task_id` = 15 )  )) ) ORDER BY addtime desc LIMIT 0,5  ";
?>