<?php
//000000000000s:72:"SELECT log_id as id FROM `dwin_log_main_table` WHERE ( `task_id` = 15 ) ";
?>