<?php
//000000000000s:159:"SELECT COUNT(*) AS tp_count FROM `dwin_reply_table` WHERE ( `id` in (( SELECT `reply_id` FROM `dwin_reply_main_table` WHERE ( `worklog_id`=30 )  )) ) LIMIT 1  ";
?>