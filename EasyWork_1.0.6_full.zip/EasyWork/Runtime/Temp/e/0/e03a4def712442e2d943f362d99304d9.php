<?php
//000000000000s:36:"SELECT * FROM `dwin_log_main_table` ";
?>