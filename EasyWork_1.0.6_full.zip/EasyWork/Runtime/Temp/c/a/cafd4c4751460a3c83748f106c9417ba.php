<?php
//000000000000s:82:"SELECT `from_id` FROM `dwin_task_table` WHERE ( id=13 and `from_id`<>2 ) LIMIT 1  ";
?>