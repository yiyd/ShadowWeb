<?php
//000000000000s:46:"SELECT * FROM `dwin_linkage` ORDER BY sort,id ";
?>