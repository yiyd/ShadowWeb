<?php
//000000000000s:59:"SELECT * FROM `dwin_user_group_table` ORDER BY access desc ";
?>