<?php
//000000000000s:31:"SELECT * FROM `dwin_log_table` ";
?>