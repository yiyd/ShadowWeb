<?php
//000000000000s:82:"SELECT COUNT(*) AS tp_count FROM `dwin_task_table` WHERE ( `status`=48 ) LIMIT 1  ";
?>