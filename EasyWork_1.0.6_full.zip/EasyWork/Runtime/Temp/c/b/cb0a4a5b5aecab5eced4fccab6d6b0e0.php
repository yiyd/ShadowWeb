<?php
//000000000000s:64:"SELECT `mode` FROM `dwin_menu` WHERE ( code='Backup' ) LIMIT 1  ";
?>