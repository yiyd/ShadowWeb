<?php
//000000000000s:39:"SELECT * FROM `dwin_log_destroy_table` ";
?>