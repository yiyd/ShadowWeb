<?php
//000000000000s:94:"SELECT pro_id as id FROM dwin_task_table as tt3 WHERE ( TO_DAYS(NOW())>TO_DAYS(tt3.enddate) ) ";
?>