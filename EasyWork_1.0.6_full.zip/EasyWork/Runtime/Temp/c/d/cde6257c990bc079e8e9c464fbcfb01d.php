<?php
//000000000000s:80:"SELECT `status`,`uptime` FROM `dwin_project_table` WHERE ( pro_id=10 ) LIMIT 1  ";
?>