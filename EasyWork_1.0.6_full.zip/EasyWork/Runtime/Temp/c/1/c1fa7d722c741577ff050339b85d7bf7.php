<?php
//000000000000s:102:"SELECT COUNT(*) AS tp_count FROM `dwin_sms_receive_table` WHERE ( user_id=2 and `status`=0 ) LIMIT 1  ";
?>