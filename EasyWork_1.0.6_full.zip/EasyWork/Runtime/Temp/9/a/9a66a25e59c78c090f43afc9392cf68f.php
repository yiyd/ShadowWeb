<?php
//000000000000s:70:"SELECT `access` FROM `dwin_user_group_table` WHERE ( id="" ) LIMIT 1  ";
?>