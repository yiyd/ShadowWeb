<?php
//000000000000s:83:"SELECT COUNT(*) AS tp_count FROM `dwin_task_table` WHERE ( `status`<>51 ) LIMIT 1  ";
?>