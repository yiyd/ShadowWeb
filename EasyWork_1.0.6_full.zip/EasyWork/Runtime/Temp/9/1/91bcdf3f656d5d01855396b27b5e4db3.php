<?php
//000000000000s:60:"SELECT `id` FROM `dwin_menu` WHERE ( _parentId=8 ) LIMIT 1  ";
?>