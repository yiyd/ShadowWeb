<?php
//000000000000s:37:"SELECT * FROM `dwin_user_part_table` ";
?>