<?php
//000000000000s:71:"SELECT log_id as id FROM `dwin_log_main_table` WHERE ( `task_id` = 5 ) ";
?>