<?php
//000000000000s:71:"SELECT `type` FROM `dwin_user_company_table` WHERE ( id="1" ) LIMIT 1  ";
?>