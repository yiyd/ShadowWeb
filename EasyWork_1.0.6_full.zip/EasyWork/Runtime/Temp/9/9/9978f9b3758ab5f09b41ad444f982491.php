<?php
//000000000000s:110:"SELECT * FROM `dwin_user_table` WHERE ( `username` = null ) AND ( `id` = null ) AND ( `status` = 1 ) LIMIT 1  ";
?>