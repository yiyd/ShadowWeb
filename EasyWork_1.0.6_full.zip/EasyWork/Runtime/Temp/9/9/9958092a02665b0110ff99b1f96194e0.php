<?php
//000000000000s:42:"SELECT * FROM `dwin_files_baseinfo_table` ";
?>