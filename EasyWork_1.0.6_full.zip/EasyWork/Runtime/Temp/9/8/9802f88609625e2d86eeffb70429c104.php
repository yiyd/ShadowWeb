<?php
//000000000000s:108:"SELECT `id`,username as text FROM `dwin_user_table` WHERE ( status=1 ) ORDER BY convert(text using gbk) asc ";
?>