<?php
//000000000000s:68:"SELECT COUNT(*) AS tp_count FROM `dwin_user_company_table` LIMIT 1  ";
?>