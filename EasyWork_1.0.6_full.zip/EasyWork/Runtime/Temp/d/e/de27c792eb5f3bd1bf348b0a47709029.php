<?php
//000000000000s:92:"SELECT `id`,title as text FROM `dwin_project_table` WHERE ( `status`<>65 and `client_id`= ) ";
?>