<?php
//000000000000s:87:"SELECT `reply_id` FROM `dwin_reply_main_table` WHERE ( `task_id`=13 and worklog_id=0 ) ";
?>