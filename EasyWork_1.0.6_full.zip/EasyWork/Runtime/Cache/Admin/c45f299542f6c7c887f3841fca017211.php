<?php if (!defined('THINK_PATH')) exit();?><script language="javascript">
function onResetNotice(){
	cancel['NoticeDetail'].dialog('close');
	cancel['NoticeDetail'].dialog('destroy');
	cancel['NoticeDetail'] = null;
}
</script>
<div class="con-tb">
<form id="detailFormNotice" method="post">
 <table class="infobox" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="13%" class="rebg"><label for="username">创建人</label></td>
    <td width="37%">
    <?php echo ($info["username"]); ?>
    </td>
    <td width="13%" class="rebg"><label for="status">状态</label></td>
    <td width="37%">
     <?php echo ($info["status"]); ?>
    </td>
  </tr>
  <tr>
    <td width="13%" class="rebg"><label for="title">公告标题</label></td>
    <td><?php echo ($info["title"]); ?></td>
    <td class="rebg"><label for="addtime">创建日期</label></td>
    <td><?php echo ($info["addtime"]); ?></td>
    </tr>
  <tr>
    <td width="13%" height="350" class="rebg"><label for="contents">公告内容</label></td>
    <td colspan="3">
    <?php echo ($info["content"]); ?>
    </td>
  </tr>
  <tr>
    <td height="38" colspan="4" align="center"><a href="javascript:void(0);" onclick="javascript:onResetNotice()" id="re" class="easyui-linkbutton" data-options="iconCls:'icon-cancel'">关闭</a></td>
  </tr>
 </table>
</form>
</div>