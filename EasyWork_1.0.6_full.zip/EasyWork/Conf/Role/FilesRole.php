<?php
$role = array(
	999=>array('r','c','u','d','p','a'),
	50=>array('r','c','u','d'),
        40=>array('r','c','u','d'),
        30=>array('r'),	
        10=>array('r'),	
	'user'=>'a',
);