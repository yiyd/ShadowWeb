<?php
$role = array(
	999=>array('r','c','u','d','p','a'),
	50=>array('r','c','u','d','p'),
	40=>array('r','c','u','d'),
	30=>array('r','c','u','d'),
	10=>array('r','c','u','d'),	
	'user'=>'a',
);