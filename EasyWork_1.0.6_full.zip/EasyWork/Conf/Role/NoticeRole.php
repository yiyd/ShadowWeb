<?php
$role = array(
	999=>array('r','c','u','d','p','a'),
	50=>array('r'),
        40=>array('r'),
        30=>array('r'),		
	'user'=>'a',
);